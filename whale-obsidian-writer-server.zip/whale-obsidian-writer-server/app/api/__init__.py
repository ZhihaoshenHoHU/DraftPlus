# -*- coding: utf-8 -*-
from fastapi import APIRouter
from app.core.conf import settings
from app.api.admin import admin_router
from app.api.writer import writer_router


route = APIRouter(prefix=settings.API_STR)
route.include_router(admin_router)
route.include_router(writer_router)
