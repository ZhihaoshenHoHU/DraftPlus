# -*- coding: utf-8 -*-
from fastapi import APIRouter
from starlette.responses import JSONResponse

router = APIRouter()


@router.get('/health')
async def health_endpoint():
    """
    校验后端各个models服务是否正常
    :return:
    """
    return JSONResponse(status_code=200, content={"status": "ok"})


@router.get('/health/readiness')
async def health_readiness():
    return JSONResponse(status_code=200, content={"status": "ok"})


@router.get('/health/liveness')
async def health_liveness():
    """
    校验Whale Obsidian Writer Server服务是否正常，health check请使用这个接口
    :return:
    """
    return JSONResponse(status_code=200, content={"status": "ok"})
