# -*- coding: utf-8 -*-
from fastapi import APIRouter
from app.api.admin.base import router as api_health



admin_router = APIRouter()

admin_router.include_router(api_health,tags=["系统健康检查"])