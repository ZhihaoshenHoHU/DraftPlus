# -*- coding: utf-8 -*-
from fastapi import APIRouter
from app.api.writer.generate_toc import router as toc_router
from app.api.writer.generate_content import router as toc_router2
from app.api.writer.chat import router as chat_router
from app.api.writer.rewrite_catalogue import router as rewrite_router
from app.api.writer.yuming_test import router as yumingtest_router
writer_router = APIRouter()

writer_router.include_router(toc_router,tags=["目录生成"])
writer_router.include_router(toc_router2,tags=["文档生成"])
writer_router.include_router(chat_router,tags=["聊天"])
writer_router.include_router(rewrite_router,tags=["重写目录"])
writer_router.include_router(yumingtest_router,tags=['域名测试'])