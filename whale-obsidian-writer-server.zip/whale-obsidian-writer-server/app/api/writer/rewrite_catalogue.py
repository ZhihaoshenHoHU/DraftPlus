# -*- coding: utf-8 -*-
import json
import base64
import httpx
import requests
from fastapi import APIRouter
from fastapi import FastAPI, WebSocket
from starlette.responses import JSONResponse
from app.core.constants import DEFAULT_TOPIC_ID, CATALOGUE_EXAMPLE
from app.utils.response_utils import response_stream
from app.common.log import app_logger
from app.core.conf import settings
from app.utils.docchain_utils import fetch_token
router = APIRouter()
@router.websocket('/rewrite')
async def rewrite_text(websocket: WebSocket):
    await websocket.accept()
    app_logger.debug('WebSocket connection established for rewrite')

    try:
        # 接收来自客户端的数据
        data = await websocket.receive_text()
        app_logger.info(f"Received data: {data}")
        all_data = json.loads(data)

        input_string = all_data.get('input_string')
        username = all_data.get('input_username')
        password = all_data.get('input_password')

        app_logger.debug(f"Parsed data - input_string: {input_string}, username: {username}, password: {password}")

        try:
            docchain_token = await fetch_token(username, password)
            app_logger.debug(f"Received docchain_token: {docchain_token}")
        except Exception as e:
            await websocket.send_text(json.dumps({"error": "Error fetching token"}))
            await websocket.close()
            return

        # 调用重写 API
        api_url = f'{settings.OPENAI_API_BASE_URL}/v1/chat/completions'
        headers = {
            "Content-Type": "application/json",
            "Authorization": docchain_token
        }
        mycookie={"access_token": docchain_token}
        input_data = f"请重写以下内容：{input_string}"
        datas = {
            "model": "gpt-4o",
            "messages": [
                {
                    "role": "system",
                    "content": "你是一个智能助手，专注于根据用户的需求重写文本。请确保重写后的内容清晰、连贯，并符合用户的要求。"
                },
                {
                    "role": "user",
                    "content": input_data
                }
            ],
            "stream": False  # 设置为 False 以简化处理
        }
        json_data = json.dumps(datas)
        app_logger.debug(f"Request data for rewrite API: {json_data}")

        async with httpx.AsyncClient(verify=False) as client:
            try:
                response = await client.post(api_url, cookies=mycookie, data=json_data)
                response.raise_for_status()
                app_logger.debug(f"Rewrite API response status: {response.status_code}")
                response_json = response.json()
                app_logger.debug(f"Rewrite API response data: {response_json}")
                rewritten_content = response_json.get('choices')[0].get('message').get('content')
                app_logger.debug(f"Rewritten content: {rewritten_content}")
                await websocket.send_text(json.dumps({"content": rewritten_content}))
            except Exception as e:
                app_logger.error(f"Error fetching rewrite response: {e}")
                await websocket.send_text(json.dumps({"error": "Error fetching rewrite response"}))
    except Exception as e:
        app_logger.error(f"Error handling WebSocket message: {e}")
    finally:
        await websocket.close()
        app_logger.debug('WebSocket connection closed')