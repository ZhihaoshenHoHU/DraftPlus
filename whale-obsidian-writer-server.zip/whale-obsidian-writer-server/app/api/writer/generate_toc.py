# -*- coding: utf-8 -*-
import json
from fastapi import APIRouter, WebSocket
from app.core.constants import DEFAULT_TOPIC_ID, CATALOGUE_EXAMPLE
from app.utils.response_utils import response_stream
from app.common.log import app_logger
from app.core.conf import settings
from app.utils.docchain_utils import fetch_token, call_docchain_api
import httpx
router = APIRouter()

@router.websocket('/getIndex')
async def generate_toc(websocket: WebSocket):
    await websocket.accept()
    app_logger.debug('web connected')
    if True:
        data = await websocket.receive_text()
        app_logger.info(f"data received: {data}")
        all_data = json.loads(data)

        data = all_data.get('input_string')
        username = all_data.get('input_username')
        password = all_data.get('input_password')
        times = all_data.get('ask_times')
        query_type = all_data.get('query_type')
        dice = all_data.get('rolling_dice')
        topic_id = all_data.get('topicid')
        if topic_id is not None:
            topic_id = int(topic_id)
        else:
            topic_id = DEFAULT_TOPIC_ID
        if dice is not None:
            dice = int(dice)
        else:
            dice = 0
        if query_type is not None:
            query_type = int(query_type)
        else:
            query_type = 0
        if query_type != 1:
            app_logger.error("Error! Not Indexing!!")
            return
        if times is not None:
            times = int(times)
        else:
            times = 1

        try:
            docchain_token = await fetch_token(username, password)
            app_logger.debug(f'Docchain token: {docchain_token}')
        except Exception as e:
            await websocket.send_text(json.dumps({"error": "Token fetching failed"}))
            await websocket.close()
            return

        try:
            res = await call_docchain_api(data, topic_id, docchain_token)
            app_logger.debug('Docchain response: {}'.format(res))
        except Exception as e:
            await websocket.send_text(json.dumps({"error": "Docchain API call failed"}))
            await websocket.close()
            return

        api_url = f'{settings.OPENAI_API_BASE_URL}/v1/chat/completions'
        headers = {
            "Content-Type": "application/json",
            "Authorization": docchain_token
        }
        mycookie = {"access_token": docchain_token}
        input_data = f'我希望你根据{data}信息以及下面的案例内容生成一个文档目录。请参考我提供的示例，并确保生成的目录详细且符合我的要求。'
        if times > 1:
            input_data += f'，请重写目录，更贴合我的需求{data}'
        datas = {
            "model": "gpt-4o",
            "messages": [
                {
                    "role": "system",
                    "content": "你是一个智能助手，专注于根据用户的需求生成文档目录。请确保生成的目录结构清晰、逻辑性强，并能涵盖用户所需的所有主题。"
                },
                {
                    "role": "user",
                    "content": input_data
                },
                {
                    "role": "user",
                    "content": f"我可以提供3个例子，请你参照这些例子的目录格式生成符合我要求{data}的目录，只需要目录即可，不需要对目录的介绍和最后的总结，用markdown的格式书写，例子如下："
                },
                {
                    "role": "user",
                    "content": str(res[0]['data']['heading_chain']) + '，这是文章的组织方式' +
                               str(res[0]['data']['content']) + '，这是文章的内容' +
                               str(res[0]['data']['summary']) + '，这是文章的总结.'
                },
                {
                    "role": "user",
                    "content": str(res[1]['data']['heading_chain']) + '，这是文章的组织方式' +
                               str(res[1]['data']['content']) + '，这是文章的内容' +
                               str(res[1]['data']['summary']) + '，这是文章的总结.'
                },
                {
                    "role": "user",
                    "content": str(res[2]['data']['heading_chain']) + '，这是文章的组织方式' +
                               str(res[2]['data']['content']) + '，这是文章的内容' +
                               str(res[2]['data']['summary']) + '，这是文章的总结.'
                },
                {
                    "role": "user",
                    "content": '目录范式如下' + CATALOGUE_EXAMPLE + '不用写出```markdown……```'
                }
            ],
            "stream": True
        }

        try:
            async with httpx.AsyncClient(verify=False) as client:
                async with client.stream("POST", api_url, cookies=mycookie, json=datas) as gpt_response:
                    await response_stream(gpt_response, websocket)
        except Exception as e:
            json_data = json.dumps({"error": "Error fetching GPT response", "content": "\n"})
            await websocket.send_text(json_data)
            app_logger.error(f"Error fetching GPT response: {e}")
        finally:
            await websocket.close()
