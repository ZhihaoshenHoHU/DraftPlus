
from app.common.log import app_logger

from fastapi import APIRouter, WebSocket

router = APIRouter()

@router.websocket('/test')
async def test(websocket: WebSocket):
    await websocket.accept()
    app_logger.debug('web connected-test')
    await websocket.close()