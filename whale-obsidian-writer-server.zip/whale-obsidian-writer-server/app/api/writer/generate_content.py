# -*- coding: utf-8 -*-
import json
import re
import httpx
from fastapi import APIRouter, WebSocket
from app.utils.response_utils import response_stream
from app.core.constants import DEFAULT_TOPIC_ID, CONTENT_EXAMPLE
from app.common.log import app_logger
from app.core.conf import settings
from app.utils.docchain_utils import fetch_token, call_docchain_api
import asyncio
router = APIRouter()

@router.websocket('/getDocument')
async def generate_content(websocket: WebSocket):
    await websocket.accept()
    app_logger.debug('web connected')
    data = await websocket.receive_text()
    app_logger.debug(data)

    all_data = json.loads(data)
    input_string = all_data.get('input_string')
    username = all_data.get('input_username')
    password = all_data.get('input_password')
    times = all_data.get('ask_times', 1)
    query_type = all_data.get('query_type', 0)
    index = all_data.get('index', '还没有目录')
    rolling_dice = all_data.get('rolling_dice', 0)
    topic_id = all_data.get('topicid', DEFAULT_TOPIC_ID)
    index_processed = all_data.get('index_processed', 0)
    index_all = all_data.get('index_all', 0)
    existing_doc = all_data.get('output_suggestions', '')
    subtitles = re.split(r'(?<!#)(##)(?!#)', index)
    subtitles = [item for item in subtitles if item and item != '##'][1:]

    if query_type != 2:
        app_logger.error("Error! Not Indexing!!")
        await websocket.send_text(json.dumps({"finished": 1}))
        await websocket.close()
        return

    if index_processed == 0 and index_all == 0:
        index_all = len(subtitles)
        indexed = index.split('#')
        itstitle = indexed[0] if indexed[0] != '' else indexed[1]
        await websocket.send_text(json.dumps({"content": ' ' }))
        await websocket.send_text(json.dumps({"content": "#" + itstitle}))

    if index_processed >= index_all:
        app_logger.error('already finished!')
        await websocket.send_text(json.dumps({"finished": 1}))
        await websocket.close()
        return

    try:
        docchain_token = await fetch_token(username, password)
    except Exception as e:
        await websocket.send_text(json.dumps({"finished": 1}))
        await websocket.close()
        return

    thistitle = subtitles[index_processed]
    thistitles = re.split(r'(?<!#)#{3}(?!#)', thistitle)

    if not thistitles:
        app_logger.error('thistitles=0')
        await websocket.send_text(json.dumps({"finished": 1}))
        await websocket.close()
        return

    if len(thistitles) == 1:
        try:
            res = await call_docchain_api(input_string + "这是当前的目录结构： " + index + "，请基于目录提供的信息在保持目录结构不变的情况下生成完整文档", topic_id, docchain_token)
        except Exception as e:
            await websocket.send_text(json.dumps({"finished": 1}))
            await websocket.close()
            return

        messages = [
            {
                "role": "system",
                "content": "You are a helpful assistant who helps the users generate documents according to their inputs."
            },
            {
                "role": "user",
                "content": input_string + '，我希望保持我的目录不变并生成一个基于我的目录的完整文档，这是我的目录：' + index
            },
            {
                "role": "user",
                "content": "我想要分章节标题一步一步生成，这一次，现在已经基于目录生成了以下的文档：" + existing_doc
            },
            {
                "role": "user",
                "content": "现在需要生成的目录条目为第" + str(index_processed) + "条，内容为：##" + subtitles[index_processed]
            },
            {
                "role": "user",
                "content": "以上提供的是文章的二级标题和其子目录，请分析这部分的结构，假设文章标题为一级标题，用#前缀表示，我希望这次生成的内容为二级标题，用##前缀表示，也就是生成的内容加上##前缀，提供的目录项目的子目录内容为三级标题，用###前缀表示，"
            },
            {
                "role": "user",
                "content": "我希望基于已经生成的文档和此时的目录结构生成本条目录章节的详细内容，输出的结果严格按照目录的结构： " + index + "的结构生成，并且此次生成的内容应该和该目录对应的部分具有相同的格式和结构"
            },
            {
                "role": "user",
                "content": "我可以提供3个例子，请参照这些例子基于已有的目录生成正在生成的目录对应的内容，例子如下："
            },
            {
                "role": "user",
                "content": str(res[0]['data']['heading_chain']) + '，这是文章的组织方式' +
                           str(res[0]['data']['content']) + '，这是文章的内容' +
                           str(res[0]['data']['summary']) + '，这是文章的总结.'
            },
            {
                "role": "user",
                "content": str(res[1]['data']['heading_chain']) + '，这是文章的组织方式' +
                           str(res[1]['data']['content']) + '，这是文章的内容' +
                           str(res[1]['data']['summary']) + '，这是文章的总结.'
            },
            {
                "role": "user",
                "content": str(res[2]['data']['heading_chain']) + '，这是文章的组织方式' +
                           str(res[2]['data']['content']) + '，这是文章的内容' +
                           str(res[2]['data']['summary']) + '，这是文章的总结.'
            },
            {
                "role": "user",
                "content": "我只希望最后生成的是这样的格式的一个二级标题对应的内容：##二级标题 \n ###三级标题 \n ####四级标题 \n"
            },
            {
                "role": "user",
                "content": "同时我希望最后只生成我想要的目录内容没有额外的回答。"
            },
            {
                "role": "user",
                "content": "我也希望生成的内容符合目录：" + index + "，的结构并且按照标题具有统一的格式，例如：每个对应子标题前#的数量应当相等"
            },
            {
                "role": "user",
                "content": "这是一个例子，我希望能够参照这里对目录结构的分析，大标题就是一级标题，加#，二级标题前加##，三级标题前加###，四级标题前加####："+CONTENT_EXAMPLE
            }
        ]

        api_url = f'{settings.OPENAI_API_BASE_URL}/v1/chat/completions'
        headers = {
            "Authorization": docchain_token
        }
        body = {
            "model": "gpt-4o",
            "messages": messages,
            "stream": True
        }

        async with httpx.AsyncClient(verify=False) as client:
            retries = 3
            for attempt in range(retries):
                try:
                    async with client.stream("POST", api_url, cookies={"access_token": docchain_token}, json=body) as gpt_response:
                        gpt_response.raise_for_status()
                        await response_stream(gpt_response, websocket)
                        await websocket.send_text(json.dumps({"index_processed": str(index_processed + 1), "index_all": str(index_all), "content": "\n"}))
                        break
                except (httpx.RequestError, httpx.HTTPStatusError) as e:
                    app_logger.error(f"OpenAI API call failed on attempt {attempt + 1}/{retries}: {e}")
                    if attempt < retries - 1:
                        await asyncio.sleep(2 ** attempt)  # Exponential backoff
                    else:
                        await websocket.send_text(json.dumps({"error": "Error fetching GPT response", "index_processed": str(index_processed + 1), "index_all": str(index_all), "content": "\n"}))
                        await websocket.close()
                        return
    else:
        await websocket.send_text(json.dumps({"content": "##" + thistitles[0]}))
        for i in range(1, len(thistitles)):
            await websocket.send_text(json.dumps({"content": "### " + thistitles[i]}))

            try:
                res = await call_docchain_api(input_string + "这是当前的目录结构： " + index + "，请基于目录提供的信息在保持目录结构不变的情况下生成完整文档", topic_id, docchain_token)
            except Exception as e:
                await websocket.send_text(json.dumps({"finished": 1}))
                await websocket.close()
                return

            messages = [
                {
                    "role": "system",
                    "content": "You are a helpful assistant who helps the users generate documents according to their inputs."
                },
                {
                    "role": "user",
                    "content": input_string + "这是已经生成的文档，请提取上下文信息并结合这些信息根据我接下来提供的小标题的目录结构将其补全使其能够成为完整文档的一部分：" + existing_doc
                },
                {
                    "role": "user",
                    "content": "这是需要生成的内容的目录结构：" + thistitles[i] + "我希望在回答中包含刚刚提出的目录结构，但在回答的一开始没有任何数量的#，"
                },
                {
                    "role": "user",
                    "content": "我可以提供3个例子，请参照这些例子提取信息补全我提供的目录内容，例子如下："
                },
                {
                    "role": "user",
                    "content": str(res[0]['data']['heading_chain']) + '，这是文章的组织方式' +
                               str(res[0]['data']['content']) + '，这是文章的内容' +
                               str(res[0]['data']['summary']) + '，这是文章的总结.'
                },
                {
                    "role": "user",
                    "content": str(res[1]['data']['heading_chain']) + '，这是文章的组织方式' +
                               str(res[1]['data']['content']) + '，这是文章的内容' +
                               str(res[1]['data']['summary']) + '，这是文章的总结.'
                },
                {
                    "role": "user",
                    "content": str(res[2]['data']['heading_chain']) + '，这是文章的组织方式' +
                               str(res[2]['data']['content']) + '，这是文章的内容' +
                               str(res[2]['data']['summary']) + '，这是文章的总结.'
                },
                {
                    "role": "user",
                    "content": "我只希望生成我提供的目录对应的部分，而非整个文档，也不希望有多余的回答"+CONTENT_EXAMPLE
                }
            ]

            api_url = f'{settings.OPENAI_API_BASE_URL}/v1/chat/completions'
            headers = {
                "Authorization": docchain_token
            }
            body = {
                "model": "gpt-4o",
                "messages": messages,
                "stream": True
            }

            async with httpx.AsyncClient(verify=False) as client:
                retries = 3
                for attempt in range(retries):
                    try:
                        async with client.stream("POST", api_url, cookies={"access_token": docchain_token}, json=body) as gpt_response:
                            gpt_response.raise_for_status()
                            res = await response_stream(gpt_response, websocket)
                            existing_doc += res
                            await websocket.send_text(json.dumps({"index_processed": str(index_processed + 1), "index_all": str(index_all), "content": "\n"}))
                            break
                    except (httpx.RequestError, httpx.HTTPStatusError) as e:
                        app_logger.error(f"OpenAI API call failed on attempt {attempt + 1}/{retries}: {e}")
                        if attempt < retries - 1:
                            await asyncio.sleep(2 ** attempt)  # Exponential backoff
                        else:
                            await websocket.send_text(json.dumps({"error": "Error fetching GPT response", "index_processed": str(index_processed + 1), "index_all": str(index_all), "content": "\n"}))
                            await websocket.close()
                            return
            await websocket.send_text(json.dumps({"content": "\n"}))
