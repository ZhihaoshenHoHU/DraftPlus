from app.utils.response_utils import response_stream
from app.core.constants import DEFAULT_TOPIC_ID, CONTENT_EXAMPLE
from app.utils.response_utils import response_stream
from app.common.log import app_logger
from app.core.conf import settings
import asyncio
import re
import nest_asyncio
from fastapi.middleware.cors import CORSMiddleware
import sseclient
import logging
# -*- coding: utf-8 -*-
import json
import base64
import httpx
import requests
from fastapi import APIRouter
from fastapi import FastAPI, WebSocket


router = APIRouter()
# 配置日志输出格式和级别


@router.websocket('/getDocument')
async def generate_content(websocket: WebSocket):
    await websocket.accept()
    app_logger.debug('web connected')
    if True:
        data = await websocket.receive_text()
        app_logger.debug(data)

        all_data = json.loads(data)
        data = all_data.get('input_string')
        username = all_data.get('input_username')
        password = all_data.get('input_password')
        times = all_data.get('ask_times')
        query_type = all_data.get('query_type')
        index = all_data.get('index')
        dice = all_data.get('rolling_dice')
        topidId = all_data.get('topicid')
        index_processed = all_data.get('index_processed')
        index_all = all_data.get('index_all')
        existing_doc = all_data.get('output_suggestions')
        subtitles = re.split(r'(?<!#)(##)(?!#)', index)
        subtitles = [item for item in subtitles if item and item != '##']  # 去除空字符串
        subtitles = subtitles[1:]

        if index_processed is not None:
            index_processed = int(index_processed)
        else:
            index_processed = 0
        if index_all is not None:
            index_all = int(index_all)
        else:
            index_all = 0
        if index is None:
            index = '还没有目录'
        if topidId is not None:
            topidId = int(topidId)
        else:
            topidId = DEFAULT_TOPIC_ID
        if dice is not None:
            dice = int(dice)
        else:
            dice = 0
        if query_type is not None:
            query_type = int(query_type)
        else:
            query_type = 0
        if query_type != 2:
            app_logger.error("Error!Not Indexing!!")
            json_data = json.dumps({"finished": 1})
            await websocket.send_text(json_data)
            await websocket.close()
            return
        if times is not None:
            times = int(times)
        else:
            times = 1
        length = len(data)

        app_logger.debug('index_processed: ' + str(index_processed))
        app_logger.debug('index_all: ' + str(index_all))
        if (index_processed == 0 and index_all == 0):
            index_all = len(subtitles)
            indexed = index.split('#')
            app_logger.debug("indexed: {}".format(indexed))
            itstitle = indexed[0]
            if itstitle == '':
                itstitle = indexed[1]

            json_datas = json.dumps({"content": ' '})
            await websocket.send_text(json_datas)

            json_datas = json.dumps({"content": "#" + itstitle})

            await websocket.send_text(json_datas)

        if (index_processed >= index_all):
            app_logger.error('already finished!')
            json_data = json.dumps({"finished": 1})
            await websocket.send_text(json_data)
            await websocket.close()
            return
        app_logger.debug("subtitles: {}".format(subtitles))
        thistitle = subtitles[index_processed]
        sub_index = ""
        for i in range(index_processed):
            sub_index += subtitles[i]

        app_logger.debug('sub_index' + sub_index)
        app_logger.debug('thistitle: {}'.format(thistitle))
        thistitles = re.split(r'(?<!#)#{3}(?!#)', thistitle)
        app_logger.debug('thistitles: {}'.format(thistitles))
        token_url = f'{settings.DOCCHAIN_URL}/v1/auth/login'
        password_string = password
        byte_string = password_string.encode('utf-8')
        token_body = {
            "username": username,
            "password": base64.b64encode(byte_string).decode('utf-8'),
        }
        try:
            token_response = requests.post(token_url, json=token_body,verify=False )
            token_response.raise_for_status()
            docchain_token = token_response.cookies.get('access_token')

        except Exception as e:
            app_logger.error(e)
            json_data = json.dumps({"finished": 1})
            await websocket.send_text(json_data)
            await websocket.close()
            return

        if len(thistitles) == 0:
            app_logger.error('thistitles=0')
            json_data = json.dumps({"finished": 1})
            await websocket.send_text(json_data)
            await websocket.close()
            return
        if len(thistitles) == 1:
            api_url = f'{settings.DOCCHAIN_URL}/v1/search'
            headers = {
                # "Content-Type": "application/json",
                "access_token": docchain_token
            }
            mycookie = {"access_token": docchain_token}
            body = {

                "query": data + "这是当前的目录结构： " + index + "，请基于目录提供的信息在保持目录结构不变的情况下生成完整文档",  # 查询问题
                "topic_id": topidId,  # 主题id
                "size": 5,  # 返回知识分块的数量
                "with_context": False,
                "score": 0.1,  # 返回元素的最小得分，只在rerank下有意义
                "ranking_mode": "rrf",  # 可选值:rerank、rrf，rerank需要GPU支持，rrf不需要GPU
                "rrf_k": 60,  # rrf计算分数用的参数，值小代表排名优先，值大代表在多路召回中出现的次数优先，建议为10
            }

            json_data = json.dumps(body)
            response = requests.post(api_url, data=json_data, cookies=headers,verify=False)
            res = response.json()['text']
            app_logger.debug('Docchain response: {}'.format(res))

            # 检查请求是否成功
            if response.status_code == 200:
                app_logger.debug('Docchain API call successful')
            else:
                app_logger.error('Error:', response.status_code, response.text)

            api_url = f'{settings.OPENAI_API_BASE_URL}/v1/chat/completions'
            headers = {
                "Content-Type": "application/json",
                "Authorization": docchain_token
            }

            input_data = data + '，我希望保持我的目录不变并生成一个基于我的目录的完整文档，这是我的目录：' + index

            if (times > 1):
                input_data += '，请基于要求和目录更加详细地生成一个符合我的要求的完整的文档'
            datas = {
                "model": "gpt-4o",
                "messages": [
                    {
                        "role": "system",
                        "content": "You are a helpful assistant who helps the users generate documents according to their inputs."
                    },

                    {
                        "role": "user",
                        "content": input_data + "我想要分章节标题一步一步生成，这一次，现在已经基于目录生成了以下的文档：" + existing_doc
                    },
                    {
                        "role": "user",
                        "content": "现在需要生成的目录条目为第" + str(index_processed) + "条，内容为：##" + subtitles[index_processed]
                    },
                    {
                        "role": "user",
                        "content": "以上提供的是文章的二级标题和其子目录，请分析这部分的结构，假设文章标题为一级标题，用#前缀表示，我希望这次生成的内容为二级标题，用##前缀表示，也就是生成的内容加上##前缀，提供的目录项目的子目录内容为三级标题，用###前缀表示，"
                    },
                    {
                        "role": "user",
                        "content": "我希望基于已经生成的文档和此时的目录结构生成本条目录章节的详细内容，输出的结果严格按照目录的结构： " + index + "的结构生成，并且此次生成的内容应该和该目录对应的部分具有相同的格式和结构"
                    },
                    {
                        "role": "user",
                        "content": "我可以提供3个例子，请参照这些例子基于已有的目录生成正在生成的目录对应的内容，例子如下："
                    },
                    {
                        "role": "user",
                        "content": str(res[0]['data']['heading_chain']) + '，这是文章的组织方式' +
                                   str(res[0]['data']['content']) + '，这是文章的内容' +
                                   str(res[0]['data']['summary']) + '，这是文章的总结.'
                    },
                    {
                        "role": "user",
                        "content": str(res[1]['data']['heading_chain']) + '，这是文章的组织方式' +
                                   str(res[1]['data']['content']) + '，这是文章的内容' +
                                   str(res[1]['data']['summary']) + '，这是文章的总结.'
                    },
                    {
                        "role": "user",
                        "content": str(res[2]['data']['heading_chain']) + '，这是文章的组织方式' +
                                   str(res[2]['data']['content']) + '，这是文章的内容' +
                                   str(res[2]['data']['summary']) + '，这是文章的总结.'
                    },
                    {
                        "role": "user",
                        "content": "我只希望最后生成的是这样的格式的一个二级标题对应的内容：##二级标题 \n ###三级标题 \n ####四级标题 \n"
                    },
                    {
                        "role": "user",
                        "content": "同时我希望最后只生成我想要的目录内容没有额外的回答。"
                    },
                    {
                        "role": "user",
                        "content": "我也希望生成的内容符合目录：" + index + "，的结构并且按照标题具有统一的格式，例如：每个对应子标题前#的数量应当相等"
                    },
                    {
                        "role": "user",
                        "content": "这是一个例子，我希望能够参照这里对目录结构的分析，大标题就是一级标题，加#，二级标题前加##，三级标题前加###，四级标题前加####："+CONTENT_EXAMPLE
                    }
                ],
                "stream": True
            }
            json_data = json.dumps(datas)

            if index_processed > 0:
                app_logger.debug('index_processed>0')
            async with httpx.AsyncClient(verify=False) as client:
                try:
                    async with client.stream("POST", api_url, cookies=mycookie, json=datas) as gpt_response:
                        await response_stream(gpt_response, websocket)

                        json_data = json.dumps(
                            {"index_processed": str(index_processed + 1), "index_all": str(index_all), "content": "\n"})

                        app_logger.debug(json_data)
                        await websocket.send_text(json_data)

                except Exception as e:

                    json_data = json.dumps(
                        {"error": "Error fetching GPT response", "index_processed": str(index_processed + 1),
                         "index_all": str(index_all), "content": "\n"})

                    await websocket.send_text(json_data)
                    app_logger.error(f"Error fetching GPT response: {e}")
                finally:

                    await websocket.close()

        else:

            json_data = json.dumps({"content": "##" + thistitles[0]})
            await websocket.send_text(json_data)
            for i in range(1, len(thistitles)):
                app_logger.debug('thistitles[i]: ', thistitles[i])
                json_datanew = json.dumps({"content": "### " + thistitles[i]})
                await websocket.send_text(json_datanew)
                api_url = f'{settings.DOCCHAIN_URL}/v1/search'
                headers = {
                    # "Content-Type": "application/json",
                    "access_token": docchain_token
                }
                mycookie = {"access_token": docchain_token}
                body = {
                    "query": data + "这是当前的目录结构： " + index + "，请基于目录提供的信息在保持目录结构不变的情况下生成完整文档",  # 查询问题
                    "topic_id": topidId,  # 主题id
                    "size": 5,  # 返回知识分块的数量
                    "with_context": False,
                    "score": 0.1,  # 返回元素的最小得分，只在rerank下有意义
                    "ranking_mode": "rrf",  # 可选值:rerank、rrf，rerank需要GPU支持，rrf不需要GPU
                    "rrf_k": 60,  # rrf计算分数用的参数，值小代表排名优先，值大代表在多路召回中出现的次数优先，建议为10
                }
                json_data = json.dumps(body)
                response = requests.post(api_url, data=json_data, cookies=headers,verify=False)
                res = response.json()['text']
                app_logger.debug(res)

                # 检查请求是否成功
                if response.status_code == 200:
                    app_logger.debug('Docchain API call successful')
                else:
                    app_logger.error('Error:', response.status_code, response.text)

                api_url = f'{settings.OPENAI_API_BASE_URL}/v1/chat/completions'
                headers = {
                    "Content-Type": "application/json",
                    "Authorization": docchain_token
                }
                mycookie = {"access_token": docchain_token}
                input_data = data

                datas = {
                    "model": "gpt-4o",
                    "messages": [
                        {
                            "role": "system",
                            "content": "You are a helpful assistant who helps the users generate documents according to their inputs."
                        },

                        {
                            "role": "user",
                            "content": input_data + "这是已经生成的文档，请提取上下文信息并结合这些信息根据我接下来提供的小标题的目录结构将其补全使其能够成为完整文档的一部分：" + existing_doc
                        },

                        {
                            "role": "user",
                            "content": "这是需要生成的内容的目录结构：" + thistitles[i] + "我希望在回答中包含刚刚提出的目录结构，但在回答的一开始没有任何数量的#，"
                        },
                        {
                            "role": "user",
                            "content": "我可以提供3个例子，请参照这些例子提取信息补全我提供的目录内容，例子如下："
                        },
                        {
                            "role": "user",
                            "content": str(res[0]['data']['heading_chain']) + '，这是文章的组织方式' +
                                       str(res[0]['data']['content']) + '，这是文章的内容' +
                                       str(res[0]['data']['summary']) + '，这是文章的总结.'
                        },
                        {
                            "role": "user",
                            "content": str(res[1]['data']['heading_chain']) + '，这是文章的组织方式' +
                                       str(res[1]['data']['content']) + '，这是文章的内容' +
                                       str(res[1]['data']['summary']) + '，这是文章的总结.'
                        },
                        {
                            "role": "user",
                            "content": str(res[2]['data']['heading_chain']) + '，这是文章的组织方式' +
                                       str(res[2]['data']['content']) + '，这是文章的内容' +
                                       str(res[2]['data']['summary']) + '，这是文章的总结.'
                        },
                        {
                            "role": "user",
                            "content": "我只希望生成我提供的目录对应的部分，而非整个文档，也不希望有多余的回答"+CONTENT_EXAMPLE
                        }
                    ],
                    "stream": True
                }
                json_data = json.dumps(datas)

                if index_processed > 0:
                    app_logger.debug('index_processed>0')
                async with httpx.AsyncClient(verify=False) as client:
                    try:
                        async with client.stream("POST", api_url, cookies=mycookie, json=datas) as gpt_response:
                            res = await response_stream(gpt_response, websocket)
                            existing_doc += res
                            json_data = json.dumps(
                                {"index_processed": str(index_processed + 1), "index_all": str(index_all),
                                 "content": "\n"})
                            app_logger.debug(json_data)
                            await websocket.send_text(json_data)
                    except Exception as e:
                        json_data = json.dumps(
                            {"error": "Error fetching GPT response", "index_processed": str(index_processed + 1),
                             "index_all": str(index_all), "content": "\n"})
                        app_logger.debug(json_data)
                        await websocket.send_text(json_data)
                        app_logger.error(f"Error fetching GPT response: {e}")
                json_datanew = json.dumps({"content": "\n"})
                await websocket.send_text(json_datanew)