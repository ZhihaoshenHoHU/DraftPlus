from app.utils.response_utils import response_stream
from app.core.constants import DEFAULT_TOPIC_ID, CATALOGUE_EXAMPLE
from app.common.log import app_logger
from app.core.conf import settings
import re
import json
import base64
import httpx
import requests
from fastapi import APIRouter, WebSocket

router = APIRouter()

@router.websocket('/chat')
async def chat(websocket: WebSocket):
    await websocket.accept()
    app_logger.debug('web connected')

    try:
        data = await websocket.receive_text()
        app_logger.info(data)
        all_data = json.loads(data)
        input_string = all_data.get('input_string')
        token = all_data.get('input_token')
        username = all_data.get('input_username')
        password = all_data.get('input_password')
        output_answer = all_data.get('output_answer')

        # 获取登录令牌
        token_url = f'{settings.DOCCHAIN_URL}/v1/auth/login'
        password_string = password.encode('utf-8')
        token_body = {
            "username": username,
            "password": base64.b64encode(password_string).decode('utf-8'),
        }
        try:
            token_response = requests.post(token_url, json=token_body,verify=False)
            token_response.raise_for_status()
            docchain_token = token_response.cookies.get('access_token')
        except Exception as e:
            app_logger.error(e)
            await websocket.send_text(json.dumps({"error": "Error fetching login token"}))
            await websocket.close()
            return
        # 调用重写 API
        api_url = f'{settings.OPENAI_API_BASE_URL}/v1/chat/completions'
        headers = {
            # "Content-Type": "application/json",
            "Authorization": docchain_token
        }
        mycookie = {"access_token": docchain_token}
        datas = {
            "model": "gpt-4o",
            "messages": [
                {
                    "role": "system",
                    "content": "你是一个智能助手，可以回答用户的各种问题。"
                },
                {
                    "role": "user",
                    "content": input_string
                }
            ],
            "stream": True
        }
        json_data = json.dumps(datas)

        async with httpx.AsyncClient(verify=False) as client:
            try:
                async with client.stream("POST", api_url, cookies=mycookie, json=datas) as gpt_response:
                    await response_stream(gpt_response, websocket)
            except Exception as e:
                await websocket.send_text(json.dumps({"error": "Error fetching GPT response"}))
                app_logger.error(f"Error fetching GPT response: {e}")
            finally:
                await websocket.close()
    except Exception as e:
        app_logger.error(f"Error handling WebSocket message: {e}")
        await websocket.close()
    finally:
        app_logger.debug('WebSocket connection closed')
