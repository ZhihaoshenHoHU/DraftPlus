import json
import base64
import httpx
from app.common.log import app_logger
from app.core.conf import settings
async def fetch_token(username:str,password:str)-> str:
    token_url = f'{settings.DOCCHAIN_URL}/v1/auth/login'
    password_string = password
    byte_string = password_string.encode("utf-8")
    token_body = {
        "username":username,
        "password":base64.b64encode(byte_string).decode('utf-8'),
    }
    async with httpx.AsyncClient(verify=False) as client:
        try:
            token_response =await client.post(token_url,json=token_body)
            token_response.raise_for_status()
            return token_response.cookies.get("access_token")
        except Exception as e:
            app_logger.error(f"Token fetching failed:{e}")
            raise
async def call_docchain_api(query:str,topic_id:int,token:str):
    api_url = f'{settings.DOCCHAIN_URL}/v1/search'
    headers={"access_token":token}
    body={
        "query":query,
        "topic_id":topic_id,
        "size":5,
        "with_context":False,
        "score":0.1,
        "ranking_mode":"rrf",
        "rrf_k":60,
    }
    async with httpx.AsyncClient(verify=False) as client:
        try:
            response = await client.post(api_url, json=body, cookies=headers)
            response.raise_for_status()
            return response.json()['text']
        except Exception as e:
            app_logger.error(f"Docchain API call failed: {e}")
            raise


