# -*- coding: utf-8 -*-
import json
import httpx
from fastapi import WebSocket
from app.common.log import app_logger


async def response_stream(response: httpx.Response, websocket: WebSocket):
    res = ''
    async for line in response.aiter_lines():
        if line:
            if line[6:] != '[DONE]':
                try:
                    if (len(line) <= 6):
                        continue
                    line = line[6:]
                    c1 = json.loads(line)

                    content = c1["choices"][0]["delta"]
                    if content:
                        content = content.get('content', '')

                        res += content
                        if content:
                            # print(content)
                            json_data = json.dumps({"content": str(content)})
                            await websocket.send_text(json_data)
                except json.JSONDecodeError as json_ex:
                    app_logger.error(f"JSON parse error for data: {line}, Exception: {json_ex}")
                except KeyError as key_error:
                    app_logger.error(f"Key error: {line}, Exception: {key_error}")
                except Exception as ex:
                    app_logger.error(f"Error processing data: {line}, Exception: {ex}")
            else:
                break

    app_logger.debug(res)
    return res
