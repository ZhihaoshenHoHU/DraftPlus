# -*- coding: utf-8 -*-
from sqlalchemy import Column, Integer, String, Text, DateTime, func,Date
from app.models.base import Base
from datetime import datetime


class GptUserUsage(Base):
    __tablename__ = 'gpt_user_usages'

    id = Column(Integer, primary_key=True, autoincrement=True)
    usage_date = Column(Date)
    user_code = Column(String(50))
    user_name = Column(String(50))
    model_name = Column(String(50))
    type = Column(String(50),  default='GPT-PROXY', comment='使用类型：GPT-PROXY,CODER-SERVER')
    usage_count = Column(Integer, default=0)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now(), onupdate=func.now())
    comment = Column(Text)

    def __repr__(self):
        return f"<GptUserUsage(id={self.id}, user_code={self.user_code}, model_name='{self.model_name}', usage_count={self.usage_count})>"
