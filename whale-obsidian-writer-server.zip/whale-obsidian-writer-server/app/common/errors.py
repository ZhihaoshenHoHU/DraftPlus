# -*- coding: utf-8 -*-
from fastapi import HTTPException
from datetime import datetime


class AuthorizationFailed(HTTPException):
    def __init__(self):
        detail = {
            "error": {
                "message": "Authorization failed.",
                "type": "authorization_failed_error",
                "param": None,
                "code": "authorization_failed"
            }
        }
        super().__init__(status_code=401, detail=detail)


class InvalidTokenError(HTTPException):
    def __init__(self, token: str):
        detail = {
            "error": {
                "message": f"Invalid token provided: {token}.",
                "type": "invalid_token_error",
                "param": None,
                "code": "invalid_token"
            }
        }
        super().__init__(status_code=401, detail=detail)



class PermissionDeniedError(HTTPException):
    def __init__(self, user_id: str):
        detail = {
            "error": {
                "message": f"Permission denied for user: {user_id}.",
                "type": "permission_denied_error",
                "param": None,
                "code": "permission_denied"
            }
        }
        super().__init__(status_code=403, detail=detail)


class ResourceNotFoundError(HTTPException):
    def __init__(self, resource: str):
        detail = {
            "error": {
                "message": f"Resource not found: {resource}.",
                "type": "resource_not_found_error",
                "param": None,
                "code": "resource_not_found"
            }
        }
        super().__init__(status_code=404, detail=detail)


class ResourceConflictError(HTTPException):
    def __init__(self, resource: str):
        detail = {
            "error": {
                "message": f"Resource conflict: {resource}.",
                "type": "resource_conflict_error",
                "param": None,
                "code": "resource_conflict"
            }
        }
        super().__init__(status_code=409, detail=detail)


class RateLimitExceededError(HTTPException):
    def __init__(self, user_id: str, reset_time: datetime, limit: int):
        reset_time_str = reset_time.strftime("%Y-%m-%d %H:%M:%S")
        detail = {
            "error": {
                "message": f"Rate limit exceeded for user: {user_id}. You have reached your quota of {limit} requests per day. Please try again after {reset_time_str}.",
                "type": "rate_limit_exceeded_error",
                "param": None,
                "code": "rate_limit_exceeded",
                "reset_time": reset_time_str,
                "limit": limit
            }
        }
        super().__init__(status_code=429, detail=detail)


class ServiceUnavailableError(HTTPException):
    def __init__(self):
        detail = {
            "error": {
                "message": "The engine is currently not available.",
                "type": "service_unavailable",
                "param": None,
                "code": "service_unavailable"
            }
        }
        super().__init__(status_code=503, detail=detail)
