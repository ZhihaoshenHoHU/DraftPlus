# -*- coding: utf-8 -*-
import os

from loguru import logger

from app.core import path_conf
from app.core.conf import settings


class AppLogger:
    def __init__(self):
        self.log_path = path_conf.LogPath
        self.ensure_log_directory_exists()

    def ensure_log_directory_exists(self):
        if not os.path.exists(self.log_path):
            os.makedirs(self.log_path)

    def initialize_logger(self):
        log_debug_file = os.path.join(self.log_path, settings.LOG_DEBUG_FILENAME)
        log_stdout_file = os.path.join(self.log_path, settings.LOG_STDOUT_FILENAME)
        log_stderr_file = os.path.join(self.log_path, settings.LOG_STDERR_FILENAME)

        log_config = dict(rotation='10 MB', retention='3 days', compression='tar.gz', enqueue=True)
        # debug
        logger.add(
            log_debug_file,
            level="DEBUG",
            filter=lambda record: record["level"].name == "DEBUG",
            **log_config,
            backtrace=True,
            diagnose=True
        )
        # stdout
        logger.add(
            log_stdout_file,
            level='INFO',
            filter=lambda record: record['level'].name == 'INFO' or record['level'].no <= 25,
            **log_config,
            backtrace=False,
            diagnose=False,
        )
        # stderr
        logger.add(
            log_stderr_file,
            level='ERROR',
            filter=lambda record: record['level'].name == 'ERROR' or record['level'].no >= 30,
            **log_config,
            backtrace=True,
            diagnose=True,
        )
        return logger


app_logger = AppLogger().initialize_logger()
