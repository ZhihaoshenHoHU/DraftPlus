# -*- coding: utf-8 -*-
import traceback
from fastapi import FastAPI, Request, HTTPException
from starlette.responses import JSONResponse

from app.common.log import app_logger


def register_exception_handlers(app: FastAPI):
    @app.exception_handler(HTTPException)
    async def http_exception_handler(request: Request, exc: HTTPException):
        """
        全局HTTP异常处理
        """
        app_logger.error(f"HTTP Exception: {exc.detail}")
        return JSONResponse(
            status_code=exc.status_code,
            content=exc.detail
        )

    @app.exception_handler(Exception)
    async def all_exception_handler(request: Request, exc: Exception):
        """
        全局异常处理
        """
        app_logger.error(f"Unknown Exception: {exc}")
        status_code = getattr(exc, 'status_code', 500)
        app_logger.error(traceback.format_exc())
        if hasattr(exc, 'detail'):
            detail = exc.detail
            return JSONResponse(
                status_code=status_code,
                content=detail
            )
        else:
            error_message = f"The server encountered an error while processing your request. {str(exc)}"
            app_logger.error(f"Unknown Exception: {exc}")
            app_logger.error(f"Status Code: {status_code}")
            app_logger.error(f"Error Message: {error_message}")

            return JSONResponse(
                status_code=status_code,
                content={
                    "error": {
                        "message": error_message,
                        "type": "server_error",
                        "code": "internal_server_error"
                    }
                }
            )
