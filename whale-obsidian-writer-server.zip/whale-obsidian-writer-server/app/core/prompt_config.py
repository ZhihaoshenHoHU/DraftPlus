# -*- coding: utf-8 -*-
# 提示词定义区，有关提示词的修改请修改此文件
PROMPTS = {

}
