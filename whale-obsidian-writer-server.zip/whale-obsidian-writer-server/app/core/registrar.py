# -*- coding: utf-8 -*-
import httpx
from contextlib import asynccontextmanager
from app.api import route
from fastapi import FastAPI, Request
from starlette.middleware.cors import CORSMiddleware
# from starlette.middleware.gzip import GZipMiddleware
# from app.middleware.rate_limit_middleware import RateLimitMiddleware
# from app.database.db_redis import redis_client
from app.core.conf import settings
from app.common.exception_handler import register_exception_handlers
from app.common.log import app_logger


@asynccontextmanager
async def register_init(app: FastAPI):
    app_logger.info("启动初始化开始")
    # 创建数据库表
    # 连接 redis
    # await redis_client.open()
    # await FastAPILimiter.init(redis_client, prefix=settings.LIMITER_REDIS_PREFIX, http_callback=http_limit_callback)
    app_logger.info("启动初始化完成")
    yield
    # 关闭 httpx.AsyncClient 实例
    await app.state.client.aclose()
    # 关闭 redis 连接
    # await redis_client.close()
    # 关闭 limiter
    # await FastAPILimiter.close()


def register_app():
    app = FastAPI(
        title=settings.TITLE,
        version=settings.VERSION,
        description=settings.DESCRIPTION,
        docs_url=settings.DOCS_URL,
        redoc_url=settings.REDOCS_URL,
        openapi_url=settings.OPENAPI_URL,
        lifespan=register_init
    )
    # 注册中间件
    register_middleware(app)
    # 注册路由
    register_router(app)
    # 全局异常处理
    register_exception_handlers(app)

    return app


def register_middleware(app: FastAPI) -> None:
    # 添加 CORS 中间件
    app.add_middleware(
        CORSMiddleware,
        allow_origins=['*'],
        allow_credentials=True,
        allow_methods=['*'],
        allow_headers=['*'],
    )



def register_router(app: FastAPI):
    app.include_router(route)
