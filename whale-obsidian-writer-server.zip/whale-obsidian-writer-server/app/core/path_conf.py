# -*- coding: utf-8 -*-
import os
from pathlib import Path

# E:\100_WORK\110_CodeBase\111_LLM\whale-obsidian-writer-server
BasePath = Path(__file__).resolve().parent.parent.parent
tiktoken_cache_dir = os.path.join(BasePath, 'tiktoken-cache')
# E:\100_WORK\110_CodeBase\111_LLM\whale-obsidian-writer-server\logs
LogPath = os.path.join(BasePath, 'logs')
ExternalPath = os.path.join(BasePath, 'external-config')
