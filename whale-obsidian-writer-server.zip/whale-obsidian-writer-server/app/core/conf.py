# -*- coding: utf-8 -*-
import os
# 假设 ExternalPath 是一个目录路径
# ExternalPath = os.path.dirname(os.path.abspath(__file__))
# print(f"ExternalPath: {ExternalPath}")  # 打印调试信息
import yaml
from functools import lru_cache
from typing import Literal
from pydantic_settings import BaseSettings, SettingsConfigDict
from app.core.path_conf import ExternalPath




class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file='.env', env_file_encoding='utf-8', extra='allow')
    # fastapi setting
    TITLE: str = 'Whale Obsidian Writer Server'
    VERSION: str = '1.0.0'
    DESCRIPTION: str = (f'Whale Obsidian Writer Server <br>'
                        f'功能说明: 提供AI文档生成API服务 <br>'
                        f'版本: {VERSION}')
    API_STR: str = ""
    DOCS_URL: str = ""
    REDOCS_URL: str = ""
    OPENAPI_URL: str = ""
    # 是否开启外网访问，外网访问无法使用研发云鉴权
    IS_INTERNET_ENV: bool = False

    # log filename setting
    LOG_STDOUT_FILENAME: str = "whale-obsidian-server.log"
    LOG_STDERR_FILENAME: str = "whale-obsidian-server-err.log"
    LOG_DEBUG_FILENAME: str = "whale-obsidian-server-debug.log"

    # DB
    MYSQL_HOST: str
    MYSQL_PORT: int
    MYSQL_USER: str
    MYSQL_PASSWORD: str
    DB_ECHO: bool = False
    DB_DATABASE: str = 'gpt_writer'
    DB_CHARSET: str = 'utf8mb4'
    # Redis
    REDIS_HOST: str
    REDIS_PORT: int
    REDIS_PASSWORD: str
    REDIS_DATABASE: int
    REDIS_TIMEOUT: int = 10
    # token本地鉴权的地址
    DOCCHAIN_URL: str = 'http://127.0.0.1:8000/decrypt'
    # DOCCHAIN_URL: str = 'http://127.0.0.1:8000/decrypt'
    # 使用的代码模型和次数限制
    OPENAI_API_BASE_URL: str = 'https://api.openai.com'
    OPENAI_API_KEY: str = 'sk-xxxxx'
    OPENAI_API_MODEL: str = 'gpt-4o-mini'

    USER_QUOTA_LIMIT: int = 1000
    MAX_HISTORY_CHAT: int = 5

    # Datetime
    DATETIME_FORMAT: str = "%Y-%m-%d %H:%M:%S"



    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.DOCS_URL = f"{self.API_STR}/docs"
        self.REDOCS_URL = f"{self.API_STR}/redocs"
        self.OPENAPI_URL = f"{self.API_STR}/openapi"

    def apply_environment_restrictions(self):
        if self.IS_INTERNET_ENV:
            self.DEV_CLOUD_AUTH_URL = ''  # 禁止在互联网环境中使用研发云鉴权
            self.INTERNET_ACCESS = False  # 确保外网访问设置为False

    def update_from_dict(self, config_dict: dict):
        for key, value in config_dict.items():
            setattr(self, key, value)  # 允许设置新的属性


def load_yaml_config(yaml_path: str = 'config.yaml') -> dict:
    yaml_config_path = os.path.join(ExternalPath, yaml_path)
    print(f"Loading configuration from: {yaml_config_path}")  # 打印调试信息
    if os.path.exists(yaml_config_path):
        with open(yaml_config_path, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)
            print(f"YAML configuration content: {config}")  # 打印调试信息
            return config
    else:
        print(f"Configuration file not found at: {yaml_config_path}")  # 打印调试信息
    return {}



# @lru_cache
# def get_settings():
#     return Settings()

@lru_cache
def get_settings(yaml_path: str = None):
    """
    以环境变量中的配置为最高优先级，其次为config.yaml配置文件，最后为默认值
    """
    yaml_config = load_yaml_config(yaml_path) if yaml_path else {}
    print(f"YAML configuration loaded: {yaml_config}")  # 打印调试信息
    all_settings = Settings()
    all_settings.update_from_dict(yaml_config)
    print(f"Settings after update: {all_settings.dict()}")  # 打印调试信息
    all_settings.apply_environment_restrictions()  # 应用环境限制
    return all_settings



settings = get_settings(yaml_path=os.path.join(os.path.dirname(__file__), "../../external-config/config.yaml"))
