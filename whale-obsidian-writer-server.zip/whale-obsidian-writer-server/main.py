# -*- coding: utf-8 -*-
from app.core.registrar import register_app

app = register_app()

if __name__ == '__main__':
    import uvicorn
    from pathlib import Path
    try:
        # uvicorn.run(app, host='0.0.0.0', port=8888)
        uvicorn.run(app=f'{Path(__file__).stem}:app',host='10.45.32.211', port=5000)
    except Exception as e:
        raise e
